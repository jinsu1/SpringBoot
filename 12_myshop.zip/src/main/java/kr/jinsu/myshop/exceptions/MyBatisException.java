package kr.jinsu.myshop.exceptions;

public class MyBatisException extends Exception{
    public MyBatisException(String message) {
        super(message);
    }
}
